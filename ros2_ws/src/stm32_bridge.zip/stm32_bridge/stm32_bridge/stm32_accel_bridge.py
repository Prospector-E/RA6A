import rclpy
from rclpy.node import Node
from trajectory_msgs.msg import JointTrajectory
from control_msgs.msg import JointTrajectoryControllerState

import serial

class STM32Bridge(Node):

    def __init__(self):
        super().__init__('stm32_accel_bridge')

        # Change port if needed
        self.serial_port = '/dev/ttyUSB0'
        self.baudrate = 115200

        try:
            self.ser = serial.Serial(self.serial_port, self.baudrate, timeout=1)
            self.get_logger().info("Serial connected to STM32")
        except:
            self.ser = None
            self.get_logger().warn("Serial not connected (mock mode)")

        self.subscription = self.create_subscription(
            JointTrajectory,
            '/arm_controller/joint_trajectory',
            self.trajectory_callback,
            10
        )

    def trajectory_callback(self, msg):

        if len(msg.points) == 0:
            return

        # Take LAST point only
        last_point = msg.points[-1]

        positions = last_point.positions
        velocities = last_point.velocities
        accelerations = last_point.accelerations

        # Safety check
        if len(velocities) == 0:
            velocities = [0.0] * len(positions)

        if len(accelerations) == 0:
            accelerations = [0.0] * len(positions)

        # Format string for STM32
        # Example:
        # P:1.57,0.5,0.3;V:0.8,0.8,0.8;A:0.5,0.5,0.5\n

        cmd = "P:" + ",".join([str(p) for p in positions])
        cmd += ";V:" + ",".join([str(v) for v in velocities])
        cmd += ";A:" + ",".join([str(a) for a in accelerations])
        cmd += "\n"

        self.get_logger().info(f"Sending to STM32: {cmd}")

        if self.ser:
            self.ser.write(cmd.encode())


def main(args=None):
    rclpy.init(args=args)
    node = STM32Bridge()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
