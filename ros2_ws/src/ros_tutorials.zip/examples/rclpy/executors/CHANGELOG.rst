^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package examples_rclpy_executors
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.15.5 (2025-10-17)
-------------------
* Fix setuptools deprecations (backport `#421 <https://github.com/ros2/examples//issues/421>`_) (`#426 <https://github.com/ros2/examples//issues/426>`_)
* Contributors: mergify[bot]

0.15.4 (2025-07-16)
-------------------

0.15.3 (2024-11-25)
-------------------

0.15.2 (2024-07-26)
-------------------

0.15.1 (2022-11-07)
-------------------

0.15.0 (2022-03-01)
-------------------

0.14.0 (2022-01-14)
-------------------
* Update maintainers to Aditya Pande and Shane Loretz (`#332 <https://github.com/ros2/examples/issues/332>`_)
* Updated maintainers (`#329 <https://github.com/ros2/examples/issues/329>`_)
* Update python nodes sigint/sigterm handling (`#330 <https://github.com/ros2/examples/issues/330>`_)
* Contributors: Aditya Pande, Audrow Nash, Ivan Santiago Paunovic

0.13.0 (2021-10-18)
-------------------

0.12.0 (2021-08-05)
-------------------

0.11.2 (2021-04-26)
-------------------
* Use underscores instead of dashes in setup.cfg (`#310 <https://github.com/ros2/examples/issues/310>`_)
* Contributors: Ivan Santiago Paunovic

0.11.1 (2021-04-12)
-------------------

0.11.0 (2021-04-06)
-------------------

0.10.3 (2021-03-18)
-------------------

0.10.2 (2021-01-25)
-------------------

0.10.1 (2020-12-10)
-------------------
* Update maintainers (`#292 <https://github.com/ros2/examples/issues/292>`_)
* Contributors: Shane Loretz

0.10.0 (2020-09-21)
-------------------

0.9.2 (2020-06-01)
------------------

0.9.1 (2020-05-26)
------------------

0.9.0 (2020-04-30)
------------------
* more verbose test_flake8 error messages (same as `ros2/launch_ros#135 <https://github.com/ros2/launch_ros/issues/135>`_)
* Contributors: Dirk Thomas

0.8.2 (2019-11-19)
------------------

0.8.1 (2019-10-24)
------------------

0.7.3 (2019-05-29)
------------------

0.7.2 (2019-05-20)
------------------
* Fix deprecation warnings (`#241 <https://github.com/ros2/examples/issues/241>`_)
* Contributors: Jacob Perron

0.7.1 (2019-05-08)
------------------

0.7.0 (2019-04-14)
------------------

0.6.2 (2019-02-08)
------------------

0.6.0 (2018-11-20)
------------------
* No changes.

0.5.1 (2018-06-27)
------------------

0.5.0 (2018-06-26)
------------------
* add pytest markers to linter tests
* set zip_safe to avoid warning during installation (`#205 <https://github.com/ros2/examples/issues/205>`_)
* Contributors: Dirk Thomas, Mikael Arguedas

0.4.0 (2017-12-08)
------------------
* Destroy nodes when the example is done (`#196 <https://github.com/ros2/examples/issues/196>`_)
* wait_for_ready_callbacks returns a tuple now (`#194 <https://github.com/ros2/examples/issues/194>`_)
  `ros2/rclpy#159 <https://github.com/ros2/rclpy/issues/159>`_ changed wait_for_ready_callbacks to manage the generator internally and return just a tuple
* Use logging (`#190 <https://github.com/ros2/examples/issues/190>`_)
* Fix import statement and usage for rclpy.node.Node (`#189 <https://github.com/ros2/examples/issues/189>`_)
* remove test_suite, add pytest as test_requires
* Follow up to executor example comments (`#184 <https://github.com/ros2/examples/issues/184>`_)
* 0.0.3
* remove Listener from the "ThrottledTalkerListener" name given that this is only a throttled talker (`#183 <https://github.com/ros2/examples/issues/183>`_)
* Examples for Executors and callback groups (`#182 <https://github.com/ros2/examples/issues/182>`_)
* Contributors: Dirk Thomas, Mikael Arguedas, Shane Loretz
