#include "ra6a_hardware/ra6a_system.hpp"
#include "pluginlib/class_list_macros.hpp"

namespace ra6a_hardware
{

hardware_interface::CallbackReturn Ra6aSystem::on_init(
  const hardware_interface::HardwareInfo & info)
{
  if (hardware_interface::SystemInterface::on_init(info) !=
      hardware_interface::CallbackReturn::SUCCESS)
  {
    return hardware_interface::CallbackReturn::ERROR;
  }

  size_t num_joints = info_.joints.size();

  positions_.assign(num_joints, 0.0);
  velocities_.assign(num_joints, 0.0);
  commands_.assign(num_joints, 0.0);

  return hardware_interface::CallbackReturn::SUCCESS;
}

std::vector<hardware_interface::StateInterface>
Ra6aSystem::export_state_interfaces()
{
  std::vector<hardware_interface::StateInterface> state_interfaces;

  for (size_t i = 0; i < info_.joints.size(); i++)
  {
    state_interfaces.emplace_back(
      info_.joints[i].name, hardware_interface::HW_IF_POSITION, &positions_[i]);

    state_interfaces.emplace_back(
      info_.joints[i].name, hardware_interface::HW_IF_VELOCITY, &velocities_[i]);
  }

  return state_interfaces;
}

std::vector<hardware_interface::CommandInterface>
Ra6aSystem::export_command_interfaces()
{
  std::vector<hardware_interface::CommandInterface> command_interfaces;

  for (size_t i = 0; i < info_.joints.size(); i++)
  {
    command_interfaces.emplace_back(
      info_.joints[i].name, hardware_interface::HW_IF_POSITION, &commands_[i]);
  }

  return command_interfaces;
}

hardware_interface::return_type Ra6aSystem::read(
  const rclcpp::Time &, const rclcpp::Duration &)
{
  // For simulation: follow commanded positions
  for (size_t i = 0; i < positions_.size(); i++)
  {
    positions_[i] = commands_[i];
  }

  return hardware_interface::return_type::OK;
}

hardware_interface::return_type Ra6aSystem::write(
  const rclcpp::Time &, const rclcpp::Duration &)
{
  // Later: send commands_[i] to STM32
  return hardware_interface::return_type::OK;
}

}  // namespace ra6a_hardware

PLUGINLIB_EXPORT_CLASS(
  ra6a_hardware::Ra6aSystem,
  hardware_interface::SystemInterface)
